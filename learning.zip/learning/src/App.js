import React from 'react';
import ViewBox from './component/ViewBox';
import './App.css';

function App() {
  return (
    <div className="App">
      <ViewBox />
    </div>
  );
}

export default App;
