import axios from 'axios';

const API_URL = 'https://dummyjson.com/todos';

export const fetchTodos = async () => {
  try {
    const response = await axios.get(API_URL);
    return response.data.todos;
  } catch (error) {
    console.error('Error fetching :', error);
    throw error;
  }
};

export const createTodo = async (newTodo) => {
    try {
      const response = await axios.post(API_URL+'/add', newTodo);
      return response.data;  // Ensure you return the correct data
    } catch (error) {
      console.error('Error creating todo:', error);
      throw error;  // This will propagate the error back to where you called the function
    }
  };

export const updateTodo = async (todoId, updatedTodo) => {
  try {
    const response = await axios.put(`${API_URL}/${todoId}`, updatedTodo);
    return response.data;
  } catch (error) {
    console.error('Error updating :', error);
    throw error;
  }
};

export const deleteTodo = async (todoId) => {
  try {
    await axios.delete(`${API_URL}/${todoId}`);
  } catch (error) {
    console.error('Error deleting :', error);
    throw error;
  }
};
