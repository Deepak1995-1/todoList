import React from 'react';

const InputForm = ({ inputText, setInputText, status, setStatus, isEditing, addTodo, updateItem }) => {
  return (
    <div className='inputForm' >
      <input
        type="text"
        value={inputText}
        onChange={(e) => setInputText(e.target.value)}
        disabled={isEditing}
        placeholder='Enter for new lead'
      />
      <select
        value={status ? 'pending' : 'completed'} 
        onChange={(e) => setStatus(e.target.value === 'pending')}
        disabled={false}
      >
        <option value="pending">Pending</option>
        <option value="completed">Completed</option>
      </select>
      {isEditing ? (
        <button type="button" onClick={updateItem}>
          Save
        </button>
      ) : (
        <button type="button" onClick={addTodo}>
          Click Me
        </button>
      )}
    </div>
  );
};

export default InputForm;
