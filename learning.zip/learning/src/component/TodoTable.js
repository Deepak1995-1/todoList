import React from 'react';
import TodoItem from './TodoItem';

const TodoTable = ({ todoList, editItem, deleteItem }) => {
  return (
    <table border={1}>
      <thead>
        <tr>
          <th>Id</th>
          <th>Todo</th>
          <th>Status</th>
          <th>UserId</th>
          <th>Update</th>
          <th>Delete</th>
        </tr>
      </thead>
      <tbody>
        {todoList.map((item) => (
          <TodoItem key={item.id} item={item} editItem={editItem} deleteItem={deleteItem} />
        ))}
      </tbody>
    </table>
  );
};

export default TodoTable;
