import React from 'react';

const TodoItem = ({ item, editItem, deleteItem }) => {
  return (
    <tr key={item.id}>
      <td>{item.id}</td>
      <td>{item.todo}</td>
      <td className={item.completed ? 'true' : 'false'} >{item.completed ? 'True' : 'False'}</td>
      <td>{item.userId}</td>
      <td>
        <button type="button" className='edit' onClick={() => editItem(item.id)}>
          Edit
        </button>
      </td>
      <td>
        <button type="button" className='delete' onClick={() => deleteItem(item.id)}>
          Delete
        </button>
      </td>
    </tr>
  );
};

export default TodoItem;
