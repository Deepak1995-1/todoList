import React, { useState, useEffect } from 'react';
import { fetchTodos, createTodo, updateTodo, deleteTodo } from '../api/services';
import InputForm from './InputForm';
import TodoTable from './TodoTable';

const ViewBox = () => {
  const [inputText, setInputText] = useState('');
  const [status, setStatus] = useState(false); // Status as boolean
  const [todoList, setTodoList] = useState([]);
  const [isEditing, setIsEditing] = useState(false);
  const [editingTodoId, setEditingTodoId] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      const todos = await fetchTodos();
      console.log(todos, todoList);
      setTodoList(todos);
    };
    fetchData();
  }, []);

  const addTodo = async () => {
    if (inputText) {
      const nextId = todoList.length > 0 ? todoList.length + 1 : 1; 
      console.log(nextId, 'nextId');
      const newTodo = {
        id: nextId,
        todo: inputText,
        completed: status,
        userId: Math.floor((Math.random() * 100) + 1),
      };
      const createdTodo = await createTodo(newTodo);  
      console.log(newTodo, 'newTodo');
      if (createdTodo) {
        setTodoList([...todoList, createdTodo]);
        setInputText('');
        setStatus(false);
      }
    }
  };

  const deleteItem = async (id) => {
    try {
      const response = await deleteTodo(id);
      if (response) {
        const updatedTodoList = todoList.filter(item => item.id !== id);
        setTodoList(updatedTodoList);
      }
    } catch (error) {
      console.error('Error deleting todo:', error);
    }
  };

  const editItem = (id) => {
    const todoToEdit = todoList.find(item => item.id === id);
    setInputText(todoToEdit.todo);
    setStatus(todoToEdit.completed); // Set the status based on the todo
    setIsEditing(true);
    setEditingTodoId(id);
  };

  const updateItem = async () => {
    if (inputText) {
      const updatedTodo = {
        todo: inputText,
        completed: status, // Send the updated status
      };

      try {
        const response = await updateTodo(editingTodoId, updatedTodo);
        // Update the local todoList with the updated todo
        const updatedTodoList = todoList.map((todo) =>
          todo.id === editingTodoId ? { ...todo, ...updatedTodo } : todo
        );

        setTodoList(updatedTodoList);
        setInputText('');
        setStatus(false);
        setIsEditing(false);
        setEditingTodoId(null);
      } catch (error) {
        console.error('Error updating todo:', error);
      }
    }
  };

  return (
    <div>
      <InputForm 
        inputText={inputText}
        setInputText={setInputText}
        status={status}
        setStatus={setStatus}
        isEditing={isEditing}
        addTodo={addTodo}
        updateItem={updateItem}
      />
      <TodoTable 
        todoList={todoList} 
        editItem={editItem} 
        deleteItem={deleteItem} 
      />
    </div>
  );
};

export default ViewBox;
